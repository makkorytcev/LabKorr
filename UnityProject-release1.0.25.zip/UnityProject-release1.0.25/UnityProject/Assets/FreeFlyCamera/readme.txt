You are using asset FreeFlyCamera (Version 1.1) 
 
It emulates control of the Scene editor camera in Play mode (in-game screen). 

It is very convenient for quick scene adding and to use it for transition in it while staying in play mode. Load the asset and just drag the script to the main camera “FreeFlyCamera.cs” – ready to use.
 
You can change parameters of rotation rate, movement, increase of transition speed, acceleration. You can activate/deactivate the rotation, transition, acceleration of movement speed.


If you have any questions or suggestions, you can send them to my email: sergeystafeyev@gmail.com.

--------------------------------------------------------


Вы используете ассет FreeFlyCamera (Версия 1.1) 
 
Эмулирует управление камерой редактора сцены в режиме игры (на игровом экране). 
 
Очень удобно быстро добавить на сцену, и использовать для перемещения по ней в игровом режиме. Загрузите ассет, и просто перетащите на основную камеру скрипт "FreeFlyCamera.cs" - готово к использованию. 
 
Можно изменить параметры скорости вращения, перемещения, увеличения скорости перемещения, ускорения. Можно активировать/деактивировать вращение, перемещение, ускорение скорости движения.  


Если у Вас есть какие-либо вопросы или предложения, можете отправить их на мой электронный адрес: sergeystafeyev@gmail.com.
